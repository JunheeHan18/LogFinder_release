# LogFinder User Manual

LogFinder searches many log files in a folder at once, lets you study what it found, and cleans up old logs.

This manual describes only what the program actually does. Button and field names are quoted exactly as they appear on screen.

---

## 1. Getting started

### Screen layout

The main window, from top to bottom:

- Title bar: the app name, theme buttons (`Auto` `Light` `Dark`), language buttons (`English` `한글`), window buttons
- Query bar: `Search Path`, `Browse`, `Keyword`, `Start`, `End`, `Search`, `Stop`
- Option row: `Deep Search` `Match Case` `Multi Keyword` `Range Scrap` `Line Scope` `Monitoring`
- Left rail: seven icon buttons (below)
- Centre: the search result list and the tabs below it
- Status bar: progress, the extensions currently in use, a progress bar

### Left rail

Top to bottom. The buttons show an icon only; hover to see the name.

- `Show Tree` / `Hide Tree`: open or close the navigator (folder tree)
- `Analyze`: open or close the analysis panel
- `Log Management`: open or close the log management panel
- `History`: bring back an earlier search
- `Settings`: open the settings window
- `Help`: open this manual
- `About`: show program information

`Analyze` and `Log Management` share the same area, so turning one on closes the other. The query bar stays usable while either is open, and starting a search returns you to the search view automatically.

### Language and theme

The language and theme chosen in the title bar apply as soon as you press them, but they are not saved by themselves. To keep them for the next run, open `Settings` and press `Save`; the settings window already holds what you just picked, so saving as-is is enough.

On a fresh install the language is English and the theme is `Auto`.

### Where settings are stored

- Settings file: `%LocalAppData%\LogFinder\LogSearch.ini`
- Log management rules: `%LocalAppData%\LogFinder\LogManagePresets.json`
- Log management reports: `%LocalAppData%\LogFinder\ManageReports\`

History is not written to disk. It is lost when the program closes.

---

## 2. Searching

### Running a search

1. Type a folder in `Search Path` or pick one with `Browse`.
2. Type what you are looking for in `Keyword`.
3. Turn on any options you need.
4. Press `Search`. Pressing Enter in the `Keyword` box does the same.

While a search runs, `Search` is disabled and `Stop` is enabled. Pressing `Stop` keeps whatever has been found so far.

If the path is blank or does not exist you get `Enter a valid search path.`; if the keyword is blank you get `Enter a keyword to search.`

### Query fields

- `Keyword`: the text to find.
- `Start`, `End`: used only when `Range Scrap` is on. They mark the first and last line of a block.

### Search options

- `Deep Search`: also scan subfolders.
- `Match Case`: when on, upper and lower case are different characters.
- `Multi Keyword`: split the keyword on `/` and treat the pieces as separate keywords.
- `Range Scrap`: collect the block between `Start` and `End`. Collected blocks are shown by `Extracted Logs` in the result list's right-click menu.
- `Line Scope`: when you pick a matched line, also show the lines around it. How many lines is set by `Line Scope` in `Settings`.
- `Monitoring`: keep watching the folder and add new or changed files to the results.

`Range Scrap` and `Line Scope` cannot both be on; turning one on turns the other off.

With `Line Scope` on, the value currently configured is shown in red at the end of the option row, or `(empty)` when it is blank.

### How the search picks files

- Only files whose extension is registered in `Settings` with `Use` ticked are scanned. The extensions in use are always shown at the bottom right of the window.
- A line matches when the keyword occurs anywhere in it. There is no regular-expression or whole-word matching.
- With `Multi Keyword` on, a line matches when any of the keywords occurs in it.
- Subfolders you have no permission to read are skipped and the search continues. If the folder given in `Search Path` itself cannot be read, a `Search Error` message appears and the search stops.
- At most 50,000 matched lines are kept per file by default. When that limit is reached the `Matched Logs` tab header says so, for example `50,000 of 120,000 lines (per-file limit)`.

### Multi keyword

Separate several keywords with `/`:

- `ERROR/WARN`
- `STATE_A/STATE_B/STATE_C`

With `Multi Keyword` off, `/` is just another character: `TX/RX` then matches only lines that literally contain `TX/RX`.

### The result list

The columns are `File Name`, `Size`, `Write Time`, `Path`. You can select several rows (Ctrl, Shift).

- Single click: the matched lines of that file appear in the `Matched Logs` tab.
- Double click: the whole file opens as a new tab below.
- Right click: a menu appears. Right-clicking a row that is not selected selects just that row.

The button row above the list:

- `Open File`: open the selected file with its associated program.
- `Open Folder`: open the containing folder in Explorer.
- `Find Duplicates`: look for repeated lines in the selected files.
- `To timeline`: send the selected files to the Timeline tab. With nothing selected, all results are sent.
- `Analyze Selected`: open the selected files in the analysis view.
- `Open Analyze`: pick files yourself and open them in the analysis view.

The right-click menu holds `Extracted Logs`, `Open Folder`, `Analyze Selected`, `Find Duplicates` and `To timeline`.

### Matched Logs tab

Shows the matched lines of the selected file as `line number  text`. The tab header also shows the line count.

The horizontal strip above the list is the match timeline. Bar height shows where matches cluster in the log. Hovering shows the number of matches in that bucket; clicking jumps to the first match there. The axis uses wall-clock time when the log has timestamps, otherwise line numbers.

### Line Scope tab

With `Line Scope` on, picking a line in `Matched Logs` shows the surrounding lines here. Lines that contain the keyword are drawn in red and bold.

The vertical strip on the right is the match mark ruler: it shows where the matches sit in the whole list, and clicking it jumps to that line.

### Document tabs

Double-clicking a result opens the whole file as a tab.

- The tab header shows the file name and a summary such as `220,145줄 · 1,203 매치`. Hover to see the full path. (This summary is printed in Korean in both languages.)
- Matched lines are red and bold, and the ruler on the right shows where they are.
- Drag a tab header to reorder it. The `Matched Logs`, `Line Scope` and `Timeline` tabs are fixed and keep their places.
- Close a tab with its `✕`.
- While `Monitoring` is on, open document tabs follow the file as it grows (about every 1.5 seconds) and keep the line you were looking at.

### Monitoring

Turn on `Monitoring` and start a search: the folder is re-scanned about once a second, and new or changed files that match are added to the results. A blinking dot and `Live monitoring active` appear in the status bar.

Press `Stop`, or turn `Monitoring` off, to end it.

---

## 3. Navigator

Open it with the first rail button. It lists drives and lets you expand folders.

- Selecting a folder sets `Search Path` to it.
- Typing a path in the query bar expands the tree to that folder.
- Right-clicking a folder offers `Timeline from this folder`.

Folder contents are not cached; they are read again every time you expand. Folders added or removed on disk therefore show up the next time you expand. A folder that could not be read keeps its previous contents so you can try again later.

---

## 4. Analysis

The analysis view studies one or more logs in depth: mark keywords with colours, show only the lines you care about, export them, or print them.

### Opening the analysis view

- `Analyze Selected` (button or right-click menu): opens the selected files in a separate window.
- `Open Analyze`: pick files and open them in a separate window.
- Dropping files on the main window: opens a separate window.
- The `Analyze` rail button: opens the in-window panel. Use `Open Analyze` inside the panel, or drop files onto it. Opening again replaces what the panel currently shows.

If no file can be opened you get `There are no valid files to open.`

A separate window is titled `AnalysisForm - {file name}` for one file and `AnalysisForm - MultiMode` for several. Files opened from the result list are always titled `AnalysisForm - MultiMode`, even when there is only one.

### Layout

- One box per file, side by side, equal widths.
- The box you are working in (the active box) has a thin border. Clicking a box body makes it active.
- The header shows the title and a `Print` button. With two or more files a `Merge` button appears as well.
- Once you register groups, a group summary overlays the top right of the box.

### Keyboard

- `Ctrl+F`: find window
- `Ctrl+D`: duplicate-logs window for the active box
- `Ctrl+Space`: register the selected text as a group
- `Ctrl+1` to `Ctrl+9`: show only that group (press again to clear)
- `Ctrl+Shift+1` to `Ctrl+Shift+9`: add or remove that group from the merged view
- `Ctrl+0`: leave the compressed view
- ``Ctrl+` ``: clear the compressed view if one is active, otherwise reset everything
- `Ctrl+C`: copy the selection (or the last clicked word when nothing is selected)
- `Ctrl+A`: select all (only the visible lines in a compressed view)
- `Ctrl` with `+` or `-`: zoom from 0.5x to 3.0x. `Ctrl` with the mouse wheel does the same.
- Arrows, `PageUp`, `PageDown`, `Home`, `End`, `Ctrl+Home`, `Ctrl+End`: move. Hold `Shift` to extend the selection.
- `Ctrl+Left` / `Ctrl+Right`: move by word
- `Shift+F10` or the menu key: open the context menu

In a separate window, `Alt` with an arrow key docks the window to half the screen. All other `Alt` combinations are passed to Windows.

### Mouse and the context menu

- Drag to select text. Dragging past the top or bottom edge scrolls automatically.
- Double-click selects a word.
- Right-click opens the menu without changing the selection.

The menu items are listed below. These items, and the buttons in the analysis dialogs, are not translated and appear in English in the Korean interface as well.

- `Copy`: copy the selection (disabled with no selection)
- `Add Group Highlight`: register the selection as a group (disabled with no selection)
- `View Group`: choose which groups to show
- `View Highlight`: turn a group's colouring on or off without filtering lines
- `Reset`: same as ``Ctrl+` ``
- `Extract Data`: export dialog (disabled when there are no groups)
- `Merge Groups`: merge dialog (only with two or more boxes)

### Highlight groups

A group marks a recurring word or event with a colour.

1. Select a word or phrase in the body.
2. Press `Ctrl+Space`, or choose `Add Group Highlight` from the context menu.

Rules:

- At most nine groups. The lowest free number is used.
- Each number has a fixed colour.
- The same keyword cannot be registered twice, but case matters here: `Error` and `error` are different keywords.
- Matching lines is case-insensitive.
- If nothing matches, no group is created.

### Compressed view

Choosing a group with `Ctrl+1` to `Ctrl+9`, or through `View Group`, folds the body down to the lines that group matched. This is the compressed view.

- Line numbers stay those of the original file, so they jump.
- Combine several groups with `Ctrl+Shift+number`.
- Keyword highlighting from Find is hidden while a compressed view is active.
- `Ctrl+0` or `Reset` returns to the full view.

### Find

`Ctrl+F` opens it. The window is titled `Find`.

- Type in `Find what :` and press `Find Next` (Enter) or `Find All`.
- `Match case`: on by default.
- `Wrap around`: continue from the start after reaching the end.
- `Find in current document` / `Find in all documents`: exactly one is always on.
- `Extract lines`: collect matched lines in the pane at the bottom of the box.
- `Direction`: `Up`, `Down`, `From top`, `From bottom`
- `Reset`: clears the highlighting and leaves the window open.
- `Cancel` or Esc: closes the window.

No hit count and no "not found" message are shown; results appear only as highlighting in the body.

### Extract

Open `Extract Data` from the context menu to save the lines of selected groups to a file.

- Groups that drive the current compressed view are ticked in advance.
- `Select All` and `Clear All` tick and untick everything.
- `Save` writes the file. The suggested name is `{source file name}_extract.txt`.
- The file holds line text only, with no line numbers. Several groups are merged and written in line order.

With nothing ticked you get `Select at least one group to export.`; if the ticked groups have no lines you get `There are no lines to export for the selected groups.` The dialog stays open either way.

### Merge groups

With two or more files open, use the `Merge` header button or `Merge Groups` in the context menu to combine groups from different files into one file.

- The table shows `File`, `Group`, `Keyword` and `Lines`.
- The suggested file name is `merged_groups_extract.txt`.
- Each group is written as a `===== file | Group n | keyword =====` header followed by `[line number] text` lines. This differs from the Extract format.

If no group exists anywhere the window does not open and `There are no groups to merge.` is shown.

### Printing

The `Print` header button prints the active box.

- In the full view the entire file is printed; in a compressed view only the visible lines. It is not limited to what is on screen.
- `Print Options` opens first: title, LogFinder branding, page number, line numbers and watermark can be turned on or off. Title, branding, page number and line numbers start on.
- `Print Preview` then lets you pick a printer and a scale (60% to 150%) and page through the output.
- `Print` sends the job straight to the chosen printer. No Windows print dialog appears.
- With nothing to print you get `There is no current state to print.`

Long lines are not wrapped; they run past the right margin and are cut off. The preview page size is fixed and may differ from the real paper size.

Print settings are forgotten when the analysis view closes.

---

## 5. Timeline

The Timeline tab merges several log files in timestamp order, so you can see what a device log and an application log were doing at the same moment.

### Adding files

The program never adds files on its own. There are five ways:

- `To timeline` in the result list (button or right-click menu): adds the selected files, or all results when nothing is selected, and turns `Matched lines only` on.
- `Add files…` in the source panel: pick files yourself.
- `Open tabs`: add every document tab currently open.
- `Timeline from this folder` in the navigator's right-click menu: adds logs with a registered extension, following the `Deep Search` setting, up to 500 files.
- Drop files or folders onto the timeline area.

`Clear` empties the list; the `✕` on a row removes just that source.

### Source panel

One row per file:

- Check box: exclude a file temporarily without removing it.
- Colour chip: the colour used for that source in the table.
- Name box: rename it to something short. Clearing it restores the file name.
- Format box: `Auto-detect`, or one of the built-in formats chosen by hand.
- Status text: the format used, how much of the sample matched, and the line count. For formats without a date it also shows where the date came from. Excluded files show the reason in red.

### Building

- `Matched lines only`: on, only the lines the search matched; off, every line.
- `Silence ≥ (s)`: insert a silence row whenever nothing was logged for at least this long. The default is 30 seconds; 0 turns it off.
- `Row limit`: 200000 by default. If the result is cut off, the status line says so.
- `Build` builds it, `Stop` cancels.

The columns are `Time`, `Source`, `Line` and `Text`. Double-clicking a row opens that file's document tab at that line.

A silence row appears in italics, for example `── silence 11m 57s ──`.

### How timestamps are read

- The first 200 lines and 200 lines from the middle are sampled. If less than 25% of the sample matches, no format is chosen.
- For formats with a time but no date, the date comes from: a date you set, then a date in the file name (such as `app-20260918.log`), then the file's last-write date, then today.
- If the clock goes backwards by more than an hour inside one file, that is treated as crossing midnight and a day is added.
- Lines without a timestamp (stack traces and the like) inherit the time of the line before them.
- A file whose format cannot be detected is excluded rather than guessed, and the reason is shown in the source panel and the status line.

---

## 6. Log management

This panel compresses or deletes logs in a folder you choose. Open it with the `Log Management` rail button.

Because the work cannot be undone, the order is fixed: `Scan`, confirm, `Run`, report.

### Building a rule

From the top:

- `Rule name`: the name to save it under.
- `Target folder`: the folder to clean. It must be a full path.
- `Archive folder`: where archives are written. It cannot be inside the target folder.
- `Target extensions (from Settings)`: tick the extensions to handle. The list holds every extension registered in `Settings`. `Search defaults` ticks the ones search uses, `All` ticks everything, `None` unticks everything.
- `Extra patterns (e.g. trace_*)`: patterns that an extension cannot express. Separate with `;` or `,`.
- `Exclude`: patterns to leave alone.
- `Older than (days)`: only files older than this. The default is 30; 0 ignores age.
- `Min size (MB)`: only files at least this large. 0 ignores size.
- `Content keyword`: see below.
- `Action`: `Archive only`, `Delete only`, `Archive then delete`
- `Group depth`: 0 makes one archive for the whole target folder, 1 makes one per immediate subfolder.
- `Compression`: `NoCompression`, `Fastest`, `Optimal`, `SmallestSize`
- `If the archive exists`: `Skip`, `Overwrite`, `Add timestamp`
- `Delete mode`: `Recycle Bin`, `Permanent`
- `Remove empty folders`: also remove folders left empty after deleting.

`Save` stores the rule under its name and the `Rule` list brings it back. `New` starts an empty rule.

A non-numeric value in a number field blocks the scan instead of quietly disabling that condition.

### Content keyword

Use this to narrow the target by what is inside the files. Matching follows the same rules as search.

- `Do not look inside files`: no file is opened.
- `Contains any keyword (same as search)`: any one keyword is enough.
- `Contains every keyword`: all keywords must be present.
- `Exclude files that contain a keyword`: files containing a keyword are spared; the others are the targets.

`Multi Keyword` splits on `/` exactly like search, and `Match Case` behaves the same way.

The content condition is applied only to files that already passed the extension, age and size conditions. A file that cannot be read is never targeted.

### Scan and run

`Scan` only builds a plan; nothing on disk is touched. The upper tabs show `Archives / groups` (`Folder`, `Files`, `Size`, `Archive file`) and `Excluded` (`Path`, `Reason`); the lower tab shows `Files in the selected group` (`Path`, `Size`, `Modified`, plus `Keyword`, `Line` and `Matched line` when a content condition was used).

`Run` is enabled only after a scan. Editing any field discards the plan, so scan again.

`Run` asks for confirmation:

- always once, with `Cancel` as the default button;
- a second time when more than 1,000 files or more than 1 GB are involved.

When it finishes, the `Report` tab shows the result and the same text is written to a file.

### Safety rules

- Archives are written under a temporary name, reopened and verified, and only verified files are deleted.
- Files that disappeared, shrank or were written again between the scan and the run are dropped, with the reason recorded.
- Where the Recycle Bin cannot be used (network paths, removable and optical drives) nothing is deleted and you are told. It never falls back to permanent deletion silently.
- Drive roots, paths that are too shallow, Windows, user and program folders, linked folders, and an archive folder inside the target folder are all refused.
- Patterns that match every file, such as `*` or `*.*`, are refused.
- If two groups would produce the same archive name, the run is refused.

---

## 7. Find duplicates

Finds repeated lines. Select files in the result list and press `Find Duplicates`, or use the right-click menu. In the analysis view, `Ctrl+D` opens it for the file you are looking at.

`Ignore As Variable Part` tells it which parts change from line to line:

- `Timestamps`, `Dates`, `GUIDs`: on by default.
- `Hex Values`, `All Numbers`: off by default.
- `Collapse Spaces`: treat runs of spaces as one. On by default.
- `Match Case`: on by default.
- `Consecutive Only`: count only lines repeated back to back.
- `Min Count`: how many occurrences to report. The default is 2.
- `Custom Regex`: your own pattern, removed before the presets.

`Scan` starts and `Stop` cancels. The result columns are `Count`, `File`, `Sample Line` and `Line Numbers`. Double-clicking a row opens that file in the analysis view at that line.

`Export` saves a report; the suggested name is `duplicate_report.txt`. If you stop a scan the result is reported as partial and export stays disabled.

---

## 8. History

Open it with the `History` rail button. Every completed search adds its path, keyword and time. Searching the same path and keyword again updates the existing entry.

`Open`, or a double click, restores that search path, keyword and options together with the result list, so nothing has to be searched again.

`Clear` removes everything. History is not written to disk, so it is gone when the program closes.

---

## 9. Settings

Open it with the `Settings` rail button.

- `Default Path`: the search path used when the program starts.
- `Extensions`: which extensions search looks at. Clearing `Use` removes one from searches. Manage the list with `Add` and `Delete`.
- `Deep Search`, `Range Scrap`: the values used at start-up.
- `Language`: `English` or `한글`
- `Theme`: `Auto`, `Light`, `Dark`
- `Line Scope`: how many lines around a match to show, written as `10`, `+10` or `-10`. Up to three digits including the sign.

`Save` applies everything at once and writes it to the settings file; no restart is needed. Note that saving also replaces the current search path box with `Default Path`.

---

## 10. Help and About

- `Help` shows this manual. Double-click an entry in the list on the left to jump to it, or type in the box above the list to filter the entries. `Print` prints the text.
- `About` shows the product name, version, developer and contact address.

---

## 11. Common workflows

### Finding errors in a folder

1. Set `Search Path`.
2. Type `ERROR/FATAL` in `Keyword` and turn on `Multi Keyword`.
3. Press `Search`.
4. Pick a file in the results and read `Matched Logs`.
5. For surrounding context, turn on `Line Scope` and pick a line.

### Seeing what several logs did at the same moment

1. Search for the files you need.
2. Select them and press `To timeline`.
3. Leave `Matched lines only` on for events only, or turn it off for everything, then press `Build`.
4. Use the silence rows to find where logging stopped.

### Studying one file in depth

1. Select the file and press `Analyze Selected`.
2. Select a recurring word and press `Ctrl+Space` to register a group.
3. Use `Ctrl+1` to `Ctrl+9` to show that group alone.
4. Export with `Extract Data` or print with `Print` if needed.

### Cleaning up old logs

1. Open `Log Management` from the rail.
2. Set `Target folder`, `Archive folder`, `Target extensions` and `Older than (days)`.
3. Leave `Action` on `Archive then delete` and press `Scan`.
4. Check the target list and the excluded list.
5. Press `Run` and answer the confirmation.
6. Read the result in the `Report` tab.

---

## 12. Things worth knowing

- The analysis context menu and the Extract, Merge, Print Options and Print Preview dialogs are in English only; they are not translated.
- A search keeps at most 50,000 matched lines per file. When that limit is hit, the `Matched Logs` tab header says so.
- The `Line Scope` and `Monitoring` buttons are not remembered; they start off every time the program runs.
- Language and theme picked in the title bar only survive a restart if you press `Save` in `Settings`.
- History is lost when the program closes.
- Log management and duplicate reports are written where you choose, or to `%LocalAppData%\LogFinder\ManageReports\`.
